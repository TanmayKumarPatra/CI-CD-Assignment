#!/usr/bin/env bash
export MYSQL_DATABASE=userDb
export MYSQL_USER=app-root
export MYSQL_PASSWORD=root123
export MYSQL_HOST=localhost
#export MYSQL_CI_URL=jdbc:mysql://localhost:3306/userDb
