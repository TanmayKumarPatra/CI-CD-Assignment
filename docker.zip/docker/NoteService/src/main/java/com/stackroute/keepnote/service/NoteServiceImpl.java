package com.stackroute.keepnote.service;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.keepnote.exception.NoteNotFoundExeption;
import com.stackroute.keepnote.model.Note;
import com.stackroute.keepnote.model.NoteUser;
import com.stackroute.keepnote.repository.NoteRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */
@Service
public class NoteServiceImpl implements NoteService{

	/*
	 * Autowiring should be implemented for the NoteRepository and MongoOperation.
	 * (Use Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword.
	 */
	NoteRepository noteRepository;
	
	@Autowired
	public NoteServiceImpl(NoteRepository noteRepository) {
		this.noteRepository = noteRepository;
	}
	
	/*
	 * This method should be used to save a new note.
	 */
	public boolean createNote(Note note) {
		
		boolean status = false;
		NoteUser user = new NoteUser();
		note.setNoteCreationDate(new Date());
		NoteUser newUser = noteRepository.insert(user);
		if(newUser == null) {
			status = false;
		}else {
			status = true;
		}
		return status;
	}
	
	/* This method should be used to delete an existing note. */

	
	public boolean deleteNote(String userId, int noteId) {
		
		boolean status = false;
		int flag = 0;
		NoteUser user = noteRepository.findById(userId).get();
		List<Note> notes = user.getNotes();
		
		for(int i = 0; i < notes.size(); i++) {
			if(notes.get(i).getNoteId() == noteId) {
				notes.remove(i);
				user.setNotes(notes);
				noteRepository.save(user);
				flag = 1;
				break;
			}
		}
		
		if(flag == 1) {
			status = true;
		}else {
			status = false;
		}
		return status;
	}
	
	/* This method should be used to delete all notes with specific userId. */

	
	public boolean deleteAllNotes(String userId) {
		
		boolean status = false;
		NoteUser user = noteRepository.findById(userId).get();
		List<Note> notes = user.getNotes();
		
		if(user == null || notes == null) {
			status = false;
		}else {
			user.setNotes(null);
			noteRepository.save(user);
			status = true;
		}
		return status;
	}

	/*
	 * This method should be used to update a existing note.
	 */
	public Note updateNote(Note note, int id, String userId) throws NoteNotFoundExeption {
		
		int index = 0;
		Note tempNote = null;
		NoteUser user ;
		try{
			user = noteRepository.findById(userId).get();
		}catch(NoSuchElementException e)
		{
			throw new NoteNotFoundExeption("");
		}
		List<Note> notes = user.getNotes();
		
		for(int i = 0; i < notes.size(); i++) {
			if(notes.get(i).getNoteId() == id) {
				tempNote = notes.get(i);
				index = i;
			}
		}
		
		if(tempNote == null) {
			throw new NoteNotFoundExeption("");
		}
			tempNote.setCategory(note.getCategory());
			tempNote.setNoteContent(note.getNoteContent());
			tempNote.setNoteCreatedBy(note.getNoteCreatedBy());
			tempNote.setNoteCreationDate(note.getNoteCreationDate());
			tempNote.setNoteStatus(note.getNoteStatus());
			tempNote.setNoteTitle(note.getNoteTitle());
			tempNote.setReminders(note.getReminders());
			
			notes.set(index, tempNote);
			user.setNotes(notes);
			noteRepository.save(user);
		
		return tempNote;
	}

	/*
	 * This method should be used to get a note by noteId created by specific user
	 */
	public Note getNoteByNoteId(String userId, int noteId) throws NoteNotFoundExeption {
		
		Note tempNote = null;
		NoteUser user ;
		try{
			user = noteRepository.findById(userId).get();
		}catch(NoSuchElementException e)
		{
			throw new NoteNotFoundExeption("");
		}
		List<Note> notes = user.getNotes();
		
		for(int i = 0; i < notes.size(); i++) {
			if(notes.get(i).getNoteId() == noteId) {
				tempNote = notes.get(i);
			}
		}
		if(tempNote == null) {
			throw new NoteNotFoundExeption("");
		}
		return tempNote;
	}

	/*
	 * This method should be used to get all notes with specific userId.
	 */
	public List<Note> getAllNoteByUserId(String userId) {
		
		List<Note> noteList = null;
		NoteUser user = noteRepository.findById(userId).get();
		noteList = user.getNotes();
		
		return noteList;
	}

}
